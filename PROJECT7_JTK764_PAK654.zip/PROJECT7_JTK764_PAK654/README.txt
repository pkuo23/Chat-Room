README FOR: CHAT ROOM PROJECT
 * EE422C Project 7 submission by
 * <Josh Knight>
 * <JTK764>
 * <16740>
 * <Peter Kuo>
 * <PAK654>
 * <16445>
 * Slip days used: <1>
 * Fall 2016
 */

git URL: https://github.com/pkuo23/Chat-Room.git

Our project includes 2 java files and accompanying executable jar files:

1. ClientMain.java
2. ServerMain.java

We will also submit a team_plan PDF as well as this README which will define the function of our project.

Our chat room is capable of handling multiple clients on a local server. Clients can input usernames which
the server will save into a HashSet and update as new clients enter the server. The server prints this list 
to the screen anytime that a user first enters the chat.The server successfully checks for and handles 
duplicate names. 

Any message that a client sends to the server is sent to the rest of the clients in the chat.

If a user connects or disconnects, the rest of the chat is notified by the server.

